// Marcela Fuentes, A01748161
// Prueba de pasos con Búsqueda Ordenada II, comparación con Binaria

#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;

int busquedaAux(int *a, int inicio, int fin, int buscado) {
    for(int i=inicio; i<=fin; i++) {
        if(a[i]==buscado) {
            return i;
        }
    }
    return -1;
}

int busquedaOrdenada2(int *a, int size, int buscado, int paso) {
    int i=0;
    for(int i=0; i<size; i+=paso) {
        int finBloque=i+paso-1;
        if(size-1<finBloque) {
            finBloque=size-1;
        } 

        if(a[finBloque]>=buscado) {
            return busquedaAux(a, i, finBloque, buscado);
        }
    }
    return -1;
}

int busquedaBinaria(int *a, int inicio, int fin, int buscado) {
    if (fin<inicio) {
        return -1;
    }
    int medio = (fin+inicio)/2;
    if (buscado==a[medio]) {
        return medio;
    } else if (buscado<a[medio]) {
        return busquedaBinaria(a, inicio, medio-1, buscado);
    } else {
        return busquedaBinaria(a, medio+1, fin, buscado);
    }
}

int main() {
    int size=100000;
    int *a=new int[size]();
    a[4]=5;
    a[499]=500;
    a[44999]=45000;
    a[7918]=7919;
    a[9852]=9853;

    // Primera ronda, paso 2
    auto inicial1 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 2);
    auto fin1 = high_resolution_clock::now();
    auto duracion1 = duration_cast<nanoseconds>(fin1-inicial1).count();
    cout<<"Ordenada II (Paso 2, 5): "<<duracion1<<endl;

    auto inicial2 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 2);
    auto fin2 = high_resolution_clock::now();
    auto duracion2 = duration_cast<nanoseconds>(fin2-inicial2).count();
    cout<<"Ordenada II (Paso 2, 500): "<<duracion2<<endl;

    auto inicial3 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 2);
    auto fin3 = high_resolution_clock::now();
    auto duracion3 = duration_cast<nanoseconds>(fin3-inicial3).count();
    cout<<"Ordenada II (Paso 2, 45000): "<<duracion3<<endl;

    auto inicial4 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 2);
    auto fin4 = high_resolution_clock::now();
    auto duracion4 = duration_cast<nanoseconds>(fin4-inicial4).count();
    cout<<"Ordenada II (Paso 2, 7919): "<<duracion4<<endl;

    auto inicial5 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 2);
    auto fin5 = high_resolution_clock::now();
    auto duracion5 = duration_cast<nanoseconds>(fin5-inicial5).count();
    cout<<"Ordenada II (Paso 2, 9853): "<<duracion5<<endl;

    cout<<""<<endl;

    // Paso 3
    auto inicial6 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 3);
    auto fin6 = high_resolution_clock::now();
    auto duracion6 = duration_cast<nanoseconds>(fin6-inicial6).count();
    cout<<"Ordenada II (Paso 3, 5): "<<duracion6<<endl;

    auto inicial7 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 3);
    auto fin7 = high_resolution_clock::now();
    auto duracion7 = duration_cast<nanoseconds>(fin7-inicial7).count();
    cout<<"Ordenada II (Paso 3, 500): "<<duracion7<<endl;

    auto inicial8 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 3);
    auto fin8 = high_resolution_clock::now();
    auto duracion8 = duration_cast<nanoseconds>(fin8-inicial8).count();
    cout<<"Ordenada II (Paso 3, 45000): "<<duracion8<<endl;

    auto inicial9 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 3);
    auto fin9 = high_resolution_clock::now();
    auto duracion9 = duration_cast<nanoseconds>(fin9-inicial9).count();
    cout<<"Ordenada II (Paso 3, 7919): "<<duracion9<<endl;

    auto inicial10 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 3);
    auto fin10 = high_resolution_clock::now();
    auto duracion10 = duration_cast<nanoseconds>(fin10-inicial10).count();
    cout<<"Ordenada II (Paso 3, 9853): "<<duracion10<<endl;

    cout<<""<<endl;
    
    // Paso 4
    auto inicial11 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 4);
    auto fin11 = high_resolution_clock::now();
    auto duracion11 = duration_cast<nanoseconds>(fin11-inicial11).count();
    cout<<"Ordenada II (Paso 4, 5): "<<duracion11<<endl;

    auto inicial12 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 4);
    auto fin12 = high_resolution_clock::now();
    auto duracion12 = duration_cast<nanoseconds>(fin12-inicial12).count();
    cout<<"Ordenada II (Paso 4, 500): "<<duracion12<<endl;

    auto inicial13 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 4);
    auto fin13 = high_resolution_clock::now();
    auto duracion13 = duration_cast<nanoseconds>(fin13-inicial13).count();
    cout<<"Ordenada II (Paso 4, 45000): "<<duracion13<<endl;

    auto inicial14 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 4);
    auto fin14 = high_resolution_clock::now();
    auto duracion14 = duration_cast<nanoseconds>(fin14-inicial14).count();
    cout<<"Ordenada II (Paso 4, 7919): "<<duracion14<<endl;

    auto inicial15 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 4);
    auto fin15 = high_resolution_clock::now();
    auto duracion15 = duration_cast<nanoseconds>(fin15-inicial15).count();
    cout<<"Ordenada II (Paso 4, 9853): "<<duracion15<<endl;

    cout<<""<<endl;

    // Paso 5
    auto inicial16 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 5);
    auto fin16 = high_resolution_clock::now();
    auto duracion16 = duration_cast<nanoseconds>(fin16-inicial16).count();
    cout<<"Ordenada II (Paso 5, 5): "<<duracion16<<endl;

    auto inicial17 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 5);
    auto fin17 = high_resolution_clock::now();
    auto duracion17 = duration_cast<nanoseconds>(fin17-inicial17).count();
    cout<<"Ordenada II (Paso 5, 500): "<<duracion17<<endl;

    auto inicial18 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 5);
    auto fin18 = high_resolution_clock::now();
    auto duracion18 = duration_cast<nanoseconds>(fin18-inicial18).count();
    cout<<"Ordenada II (Paso 5, 45000): "<<duracion18<<endl;

    auto inicial19 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 5);
    auto fin19 = high_resolution_clock::now();
    auto duracion19 = duration_cast<nanoseconds>(fin19-inicial19).count();
    cout<<"Ordenada II (Paso 5, 7919): "<<duracion19<<endl;

    auto inicial20 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 5);
    auto fin20 = high_resolution_clock::now();
    auto duracion20 = duration_cast<nanoseconds>(fin20-inicial20).count();
    cout<<"Ordenada II (Paso 5, 9853): "<<duracion20<<endl;

    cout<<""<<endl;

    // Paso 6
    auto inicial21 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 6);
    auto fin21 = high_resolution_clock::now();
    auto duracion21 = duration_cast<nanoseconds>(fin21-inicial21).count();
    cout<<"Ordenada II (Paso 6, 5): "<<duracion21<<endl;

    auto inicial22 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 6);
    auto fin22 = high_resolution_clock::now();
    auto duracion22 = duration_cast<nanoseconds>(fin22-inicial22).count();
    cout<<"Ordenada II (Paso 6, 500): "<<duracion22<<endl;

    auto inicial23 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 6);
    auto fin23 = high_resolution_clock::now();
    auto duracion23 = duration_cast<nanoseconds>(fin23-inicial23).count();
    cout<<"Ordenada II (Paso 6, 45000): "<<duracion23<<endl;

    auto inicial24 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 6);
    auto fin24 = high_resolution_clock::now();
    auto duracion24 = duration_cast<nanoseconds>(fin24-inicial24).count();
    cout<<"Ordenada II (Paso 6, 7919): "<<duracion24<<endl;

    auto inicial25 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 6);
    auto fin25 = high_resolution_clock::now();
    auto duracion25 = duration_cast<nanoseconds>(fin25-inicial25).count();
    cout<<"Ordenada II (Paso 6, 9853): "<<duracion25<<endl;

    cout<<""<<endl;

    // Paso 7
    auto inicial26 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 7);
    auto fin26 = high_resolution_clock::now();
    auto duracion26 = duration_cast<nanoseconds>(fin26-inicial26).count();
    cout<<"Ordenada II (Paso 7, 5): "<<duracion26<<endl;

    auto inicial27 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 7);
    auto fin27 = high_resolution_clock::now();
    auto duracion27 = duration_cast<nanoseconds>(fin27-inicial27).count();
    cout<<"Ordenada II (Paso 7, 500): "<<duracion27<<endl;

    auto inicial28 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 7);
    auto fin28 = high_resolution_clock::now();
    auto duracion28 = duration_cast<nanoseconds>(fin28-inicial28).count();
    cout<<"Ordenada II (Paso 7, 45000): "<<duracion28<<endl;

    auto inicial29 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 7);
    auto fin29 = high_resolution_clock::now();
    auto duracion29 = duration_cast<nanoseconds>(fin29-inicial29).count();
    cout<<"Ordenada II (Paso 7, 7919): "<<duracion29<<endl;

    auto inicial30 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 7);
    auto fin30 = high_resolution_clock::now();
    auto duracion30 = duration_cast<nanoseconds>(fin30-inicial30).count();
    cout<<"Ordenada II (Paso 7, 9853): "<<duracion30<<endl;

    cout<<""<<endl;

    // Paso 8
    auto inicial31 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 8);
    auto fin31 = high_resolution_clock::now();
    auto duracion31 = duration_cast<nanoseconds>(fin31-inicial31).count();
    cout<<"Ordenada II (Paso 8, 5): "<<duracion31<<endl;

    auto inicial32 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 8);
    auto fin32 = high_resolution_clock::now();
    auto duracion32 = duration_cast<nanoseconds>(fin32-inicial32).count();
    cout<<"Ordenada II (Paso 8, 500): "<<duracion32<<endl;

    auto inicial33 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 8);
    auto fin33 = high_resolution_clock::now();
    auto duracion33 = duration_cast<nanoseconds>(fin33-inicial33).count();
    cout<<"Ordenada II (Paso 8, 45000): "<<duracion33<<endl;

    auto inicial34 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 8);
    auto fin34 = high_resolution_clock::now();
    auto duracion34 = duration_cast<nanoseconds>(fin34-inicial34).count();
    cout<<"Ordenada II (Paso 8, 7919): "<<duracion34<<endl;

    auto inicial35 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 8);
    auto fin35 = high_resolution_clock::now();
    auto duracion35 = duration_cast<nanoseconds>(fin35-inicial35).count();
    cout<<"Ordenada II (Paso 8, 9853): "<<duracion35<<endl;

    cout<<""<<endl;

    // Paso 9
    auto inicial36 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 9);
    auto fin36 = high_resolution_clock::now();
    auto duracion36 = duration_cast<nanoseconds>(fin36-inicial36).count();
    cout<<"Ordenada II (Paso 9, 5): "<<duracion36<<endl;

    auto inicial37 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 9);
    auto fin37 = high_resolution_clock::now();
    auto duracion37 = duration_cast<nanoseconds>(fin37-inicial37).count();
    cout<<"Ordenada II (Paso 9, 500): "<<duracion37<<endl;

    auto inicial38 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 9);
    auto fin38 = high_resolution_clock::now();
    auto duracion38 = duration_cast<nanoseconds>(fin38-inicial38).count();
    cout<<"Ordenada II (Paso 9, 45000): "<<duracion38<<endl;

    auto inicial39 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 9);
    auto fin39 = high_resolution_clock::now();
    auto duracion39 = duration_cast<nanoseconds>(fin39-inicial39).count();
    cout<<"Ordenada II (Paso 9, 7919): "<<duracion39<<endl;

    auto inicial40 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 9);
    auto fin40 = high_resolution_clock::now();
    auto duracion40 = duration_cast<nanoseconds>(fin40-inicial40).count();
    cout<<"Ordenada II (Paso 9, 9853): "<<duracion40<<endl;

    cout<<""<<endl;

    // Paso 10
    auto inicial41 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 5, 10);
    auto fin41 = high_resolution_clock::now();
    auto duracion41 = duration_cast<nanoseconds>(fin41-inicial41).count();
    cout<<"Ordenada II (Paso 10, 5): "<<duracion41<<endl;

    auto inicial42 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 500, 10);
    auto fin42 = high_resolution_clock::now();
    auto duracion42 = duration_cast<nanoseconds>(fin42-inicial42).count();
    cout<<"Ordenada II (Paso 10, 500): "<<duracion42<<endl;

    auto inicial43 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 45000, 10);
    auto fin43 = high_resolution_clock::now();
    auto duracion43 = duration_cast<nanoseconds>(fin43-inicial43).count();
    cout<<"Ordenada II (Paso 10, 45000): "<<duracion43<<endl;

    auto inicial44 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 7919, 10);
    auto fin44 = high_resolution_clock::now();
    auto duracion44 = duration_cast<nanoseconds>(fin44-inicial44).count();
    cout<<"Ordenada II (Paso 10, 7919): "<<duracion44<<endl;

    auto inicial45 = high_resolution_clock::now();
    busquedaOrdenada2(a, size, 9853, 10);
    auto fin45 = high_resolution_clock::now();
    auto duracion45 = duration_cast<nanoseconds>(fin45-inicial45).count();
    cout<<"Ordenada II (Paso 10, 9853): "<<duracion45<<endl;

    cout<<""<<endl;
    // Comparación de Paso 10 con Búsqueda Binaria
    auto inicial46 = high_resolution_clock::now();    
    busquedaBinaria(a, 0, size-1, 5);
    auto fin46 = high_resolution_clock::now();
    auto duracion46 = duration_cast<nanoseconds>(fin46-inicial46).count();
    cout<<"Binaria (5): "<<duracion46<<endl;

    auto inicial47 = high_resolution_clock::now();    
    busquedaBinaria(a, 0, size-1, 500);
    auto fin47 = high_resolution_clock::now();
    auto duracion47 = duration_cast<nanoseconds>(fin47-inicial47).count();
    cout<<"Binaria (500): "<<duracion47<<endl; 

    auto inicial48 = high_resolution_clock::now();    
    busquedaBinaria(a, 0, size-1, 45000);
    auto fin48 = high_resolution_clock::now();
    auto duracion48 = duration_cast<nanoseconds>(fin48-inicial48).count();
    cout<<"Binaria (45,000): "<<duracion46<<endl;

    auto inicial49 = high_resolution_clock::now();    
    busquedaBinaria(a, 0, size-1, 7919);
    auto fin49 = high_resolution_clock::now();
    auto duracion49 = duration_cast<nanoseconds>(fin49-inicial49).count();
    cout<<"Binaria (7919): "<<duracion48<<endl; 

    auto inicial50 = high_resolution_clock::now();    
    busquedaBinaria(a, 0, size-1, 9853);
    auto fin50 = high_resolution_clock::now();
    auto duracion50 = duration_cast<nanoseconds>(fin50-inicial50).count();
    cout<<"Binaria (9853): "<<duracion50<<endl; 
}