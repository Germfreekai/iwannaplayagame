// Marcela Fuentes, A01748161
// Recursión

#include <iostream>
using namespace std;

int factorial(int num) {
    int res=1;
    for(int i=num; i>0; i--) {
        res=res*i;
    }
    return res;
}

int factorialRec(int num) {
    if(num==0) {
        return 1;
    } else {
        return num*factorialRec(num-1);
    }
}

int main() {
    int res=factorialRec(5);
    cout<<res<<endl;
}