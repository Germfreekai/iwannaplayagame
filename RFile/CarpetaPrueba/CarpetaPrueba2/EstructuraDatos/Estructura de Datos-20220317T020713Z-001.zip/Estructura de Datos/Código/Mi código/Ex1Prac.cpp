// Marcela Fuentes, A01748161
// Examen parcial 1, parte práctica

#include <iostream>
using namespace std;

int busquedaSecuencial(int *a, int buscado, int size) {
    for (int i=0; i<size; i++) {
        if (a[i]==buscado) {
            return i;
        }
    }
    return -1;
}

class Tienda {
    public:
        int cantProductos;
        int* inventario;
        int* catalogo;

        Tienda() {
            cout<<"¿Cuántos elementos habrá en el inventario? "<<endl;
            cin>>cantProductos;
            if (cantProductos <= 10000) {
                inventario = new int[cantProductos]();
                catalogo = new int[cantProductos]();
                for(int i=0; i<cantProductos; i++) {
                    inventario[i] = 0;
                }
            } else {
                cout<<"Error, no puede haber más de 10,000 elementos en el inventario"<<endl;
            }
            
        }

        Tienda(const Tienda& original) {
            cantProductos = original.cantProductos;
            inventario = new int[cantProductos]();
            catalogo = new int[cantProductos]();
            for(int i=0; i<cantProductos; i++) {
                inventario[i] = 0;
            }
        }

        void vender(int codbarr) {
            int index = busquedaSecuencial(inventario, codbarr, cantProductos);
            if(index == -1) {
                cout<<"No contamos con ese producto"<<endl;
                return;
            }
            inventario[index] = inventario[index] - 1;
        }

        void agregarProducto(int codbarr) {
            int index = busquedaSecuencial(catalogo, codbarr, cantProductos);
            catalogo[index]=codbarr;
            inventario[index]=0;
        }

        void stock(int codbarr, int cantidad) {
            int index = busquedaSecuencial(inventario, codbarr, cantProductos);
            if(index==-1) {
                cout<<"Ese producto no existe en el inventario"<<endl;
                return;
            }
            inventario[index] = inventario[index] + cantidad;
        }

        ~Tienda() {
            delete [] inventario;
            delete [] catalogo;
        }
};

int main() {
    Tienda t;
    t.agregarProducto(1001);
    t.agregarProducto(1002);
    t.agregarProducto(23);
    t.stock(1001, 15);
    t.stock(1002, 3);
    t.stock(1003, 1);//debe imprimir un mensaje de que el producto no existe
    t.stock(23, 1);
    t.vender(23);
    t.vender(1001);
    t.vender(1003);//debe indicar que ese producto no existe
    t.vender(23);//debe indicar que no hay existencias de ese producto
    t.stock(23, 1);
    t.vender(23);
    t.stock(23, 1);

    Tienda otra=t;
    otra.vender(23);//debe indicar que no hay existencias de ese producto;
    return 0;
}