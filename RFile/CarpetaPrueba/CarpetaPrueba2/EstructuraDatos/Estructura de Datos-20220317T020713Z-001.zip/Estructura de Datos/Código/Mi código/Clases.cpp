// Marcela Fuentes, A01748161

#include <iostream>
using namespace std;

class Animal {
    public:
        virtual void sonido()=0;
};

class Perro:public Animal {
    public:
        void sonido();
};

void Perro::sonido() {
    cout<<"guau"<<endl;
}

int main() {
    Perro p;
    p.sonido();
    return 0;
}