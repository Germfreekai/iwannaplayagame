// Marcela Fuentes, A01748161
// Actividad 1.2, Sumar números
#include <iostream>

using namespace std;

int main() {
    cout << "Este programa te ayuda a sumar la cantidad de números que quieras." << endl;
    int cant = 0;
    int suma = 0;
    int num = 0;
    cout << "¿Cuántos números deseas sumar? "<<endl;
    cin >> cant;

    for(int i = 0; i < cant; i++) {
        cout << "Inserta un número: ";
        cin >> num;
        suma = suma+num;
    }
    
    cout << "La suma de estos números es ";
    cout << suma <<endl;
}