// Marcela Fuentes, A01748161
// Actividad 3, problema 2, versión corregida

#include <iostream>
using namespace std;

class Estudiante {
    public:
        string nombre;
        string matricula;
        int materias;

        // Constructor 'normal'
        Estudiante(string nom, string mat) {
            nombre = nom;
            matricula = mat;
        }

        // Constructor de copia, 'marce' es el estudiante base
        Estudiante(const Estudiante& marce) {
            nombre = marce.nombre;
            matricula = marce.matricula;
            horario = new int[materias]();
            for(int i=0; i < marce.materias; i++) {
                horario[i] = marce.horario[i];
            }
        }

        // Destructor
        ~Estudiante() {
            cout<<"Eliminando estudiante"<<endl;
            delete [] horario;
        }
        
        void crearHorario() {
            cout<<"¿Cuántas materias cursará el alumno? ";
            cin>>materias;
            horario = new int[materias]();
            for(int i=0; i < materias; i++) {
                cout<<"Introduce el código de la materia: ";
                cin>>horario[i];
            }
        }

        void setNombre(string nom) {
            nombre = nom;
        }

        void setMatricula(string mat) {
            matricula = mat;
        }
    
    private:
        int *horario;
};

int main() {
    // Crear 1er estudiante, comprobar datos
    Estudiante marce("Marcela Fuentes", "A01748161");
    cout<<marce.nombre<<endl;
    cout<<marce.matricula<<endl;
    
    // Crear horario 1er estudiante
    marce.crearHorario();

    // Copiar 1er estudiante y crear 2do, cambiar datos y comprobarlos
    Estudiante juanito = marce;
    juanito.setNombre("Juanito Pérez");
    juanito.setMatricula("A01747160");
    cout<<juanito.nombre<<endl;
    cout<<juanito.matricula<<endl;
}