// Marcela Fuentes, A01748161
// Estructura de Datos, Examen Final

#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <unordered_set>
#include <unordered_map>
#include <map>
using namespace std;

struct Data{
    string user1;
    int inter;
    string user2;

    Data(string u1, int i, string u2){
        user1=u1;
        inter=i;
        user2=u2;
    }
};

vector<Data> interacciones;

void leerData(string path){
    ifstream fIn;
    fIn.open(path);
    string temp, line, parts;
    vector<string> valores;
    while(fIn.good()){
        getline(fIn, line); 
        istringstream s(line); 
        while (getline(s, parts, ',')) { 
                valores.push_back(parts);
         }
         if(valores[2].find('\r')!=valores[2].npos) {
            interacciones.push_back(Data(valores[0], stoi(valores[1]), valores[2].substr(0, valores[2].size()-1)));
            } else {
                interacciones.push_back(Data(valores[0], stoi(valores[1]), valores[2]));
            }   
         valores.clear(); 
    }
    fIn.close();
}

class Set1 {
    public:
        unordered_set<string> usuarios;
        unordered_map<string, vector<string> > seguidores;

        void llenarUsuarios(vector<Data> interacciones) {
            for(auto i: interacciones) {
                usuarios.insert(i.user1);
                usuarios.insert(i.user2);
            }
        }

        void llenarSeguidores(vector<Data> interacciones) {
            for(auto i: interacciones) {
                seguidores.insert({i.user1, vector<string>()});
                seguidores.insert({i.user2, vector<string>()});
                for(auto j: interacciones) {
                    if (j.inter==1) {
                        seguidores[i.user1].push_back(j.user2);
                    }
                    seguidores[i.user2].push_back(j.user1);
                }
            }
        }
        
        /*Obtén una lista de los usuarios únicos (set) y crea la función usuarioExistente,
        la cual recibe un usuario e indica si ya existe o no*/
        void usuarioExistente(string user) {
            auto buscar = usuarios.find(user);
            if (buscar==usuarios.end()) {
                cout<<"El usuario " << user << " no existe en la red social."<<endl;
            } else {
                cout<<"El usuario " << user << " sí está registrado en la red social."<<endl;
            }
        }

        /*Obtén una lista de seguidores de cada usuario (unordered map/dict) y crea la
        función esSeguidor, la cual recibe 2 usuarios A y B e indica si el usuario A
        sigue a B*/
        void esSeguidor(string userA, string userB) {
            auto primbuscar = seguidores.find(userA);
            if (primbuscar==seguidores.end()) {
                cout<<"Error,  " << userA << " no está en la red social."<<endl;
            } else {
                auto buscar = seguidores[userA].find(userB);
                if (buscar==seguidores.end()) {
                    cout<<"El usuario " << userA << " no sigue al usuario " << userB <<endl;
                } else {
                    cout<<"El usuario " << userA << " sí sigue al usuario " << userB <<endl;
                }
            }
        }
};

class Set2 {
    public:
        vector<vector<int> > edges; 
	    unordered_map<string, int> vertex;
	    vector<string> ids;
	    int currentPos;

        void agregarVertice(string user) {
		    vertex[user]=currentPos;
		    currentPos++;
		    ids.push_back(user);
		    for(int i=0; i<edges.size(); i++) {
			    edges[i].push_back(0);
		    }
		    edges.push_back(vector<int>());
		    for(int i=0; i<edges.size(); i++) {
			    edges[edges.size()-1].push_back(0);
		    }
	    }

        void agregarArco(string user1, string user2) {
            edges[vertex[user1]][vertex[user2]]=1;
            edges[vertex[user2]][vertex[user1]]=1;
	    }

        void llenarRelaciones(vector<Data> interacciones) {
            for(auto i: interacciones) {
                agregarVertice(i.user1);
                agregarVertice(i.user2);
                for(auto j: interacciones) {
                    if(j.inter==0) {
                        agregarArco(i.user1, i.user2);
                    }
                    if(j.inter==1) {
                        agregarArco(i.user2, i.user1);
                    }
                }
            }
        }

        /*Crear un grafo no dirigido que indique las relaciones entre usuarios (hay una relación siempre
        y cuando sean seguidores, ya sea unilateralmente, o como amigos). Crea la función relación,
        la cual recibe 2 usuarios A y B, e indica si hay una relación entre ellos o no*/
        void relacion(string userA, string userB) {
            string relacion="No";
            for(int i=0; i<edges[userA].size(); i++) {    // "Visitar" a los vecinos de UserA
                if(edges[userA][i]==userB) {  // UserB es vecino de UserA
                    relacion="Sí";
                }
            }
            cout << "¿Existe una relación entre " << userA << " y " << userB << "?: " << relacion << endl;
        }
};

class Set3 {
        public:
            map<int, vector<string> > seguidos;
            map<int, vector<string> > compartidos;
            map<int, vector<string> > comentarios;

            void llenarSeguidos(vector<Data> interacciones) {
                int cuenta;
                for(auto i: interacciones) {
                    auto usuarioactual1 = i.user1;                      // Para hacer la cuenta de 1 usuario a la vez
                    cuenta=0;                                           // Resetear la cuenta después de cada iteración
                    for(auto j: interacciones) {
                        if(j.user1==usuarioactual1) {                   // Recorrer la lista y ver si se trata del usuario en cuestión
                            if(j.inter==0) {
                                cuenta++;
                            }
                            if(j.inter==1) {
                                cuenta++;
                            }
                        }
                    }
                    seguidos.insert({cuenta, vector<string>()});
                    seguidos[cuenta].push_back(i.user1);                // Solo la primera columna
                }

                for(auto k: interacciones) {
                    auto usuarioactual2 = i.user2;
                    cuenta=0;
                    for(auto l: interacciones) {
                        if(l.user2==usuarioactual2) {
                            if(l.inter==1) {
                                cuenta++;
                            }
                        }
                    }
                    seguidos.insert({cuenta, vector<string>()});
                    seguidos[cuenta].push_back(i.user2);                // Segunda columna
                }


                /*for(auto i: interacciones) {
                    seguidos.insert({int(), vector<string>()});
                    for(auto j: interacciones) {
                        int cuenta=0;
                        if(j.inter==0) {
                            cuenta++;
                            seguidos[cuenta].push_back(i.user1);
                        }
                        if(j.inter==1) {
                            cuenta++;
                            seguidos[cuenta].push_back(i.user1);
                            seguidos[cuenta].push_back(i.user2);
                        }
                    }
                }*/
            }

            void llenarCompartidos(vector<Data> interacciones) {
                int cuenta;
                for(auto i: interacciones) {
                    auto usuarioactual = i.user1;           // Para hacer la cuenta de 1 usuario a la vez
                    cuenta=0;                               // Resetear la cuenta después de cada iteración
                    for(auto j: interacciones) {
                        if(j.user1==usuarioactual) {        // Recorrer la lista y ver si se trata del usuario en cuestión
                            if(j.inter==0) {                // Checar que su interacción haya sido un share
                                cuenta++;
                            }
                        }
                    }
                    compartidos.insert({cuenta, vector<string>()});
                    compartidos[cuenta].push_back(i.user1);
                }

                /*for(auto i: interacciones) {   
                    compartidos.insert({int(), vector<string>(i.user1)});                                   
                    for(auto j: interacciones) {
                        int cuenta=0;
                        if(j.inter==0) {
                            cuenta++;
                            compartidos[cuenta].push_back(i.user1);
                        }
                    }
                }*/
            }

            void llenarComentarios(vector<Data> interacciones) {
                int cuenta;
                for(auto i: interacciones) {
                    auto usuarioactual = i.user1;           // Para hacer la cuenta de 1 usuario a la vez
                    cuenta=0;                               // Resetear la cuenta después de cada iteración
                    for(auto j: interacciones) {
                        if(j.user1==usuarioactual) {        // Recorrer la lista y ver si se trata del usuario en cuestión
                            if(j.inter==1) {                // Checar que su interacción haya sido un comment
                                cuenta++;
                            }
                        }
                    }
                    comentarios.insert({cuenta, vector<string>()});
                    comentarios[cuenta].push_back(i.user1);
                }
                
                /*for(auto i: interacciones) {
                    comentarios.insert({int(), vector<string>(i.user1)});                    
                    for(auto j: interacciones) {
                        int cuenta=0;
                        if(j.inter==1) {
                            cuenta++;
                            comentarios[cuenta].push_back(i.user1);
                        }
                    }
                }*/
            }
            
            /*Crea un árbol donde el id sea la cantidad de cuentas a las que sigue un usuario. 
            Crea el método mayorSeguidor, que indique quien es el usuario que más sigue a otros*/
            void mayorSeguidor(map<int, vector<string> > seguidos) {                
                int mayor=0;
                auto mayorseg;
                for(auto i=seguidos.begin(); i!=seguidos.end(); i++) {
                    if(i->first > mayor) {
                        mayorseg = i->second;
                        mayor = i->first;
                    }                    
                }
                cout << "El usuario que más sigue a otros es: " << mayorseg << endl;
            }

            /*Crea un árbol donde el id sea la cantidad de compartir. Crea un método llamado 
            amplificador que indica quien es el usuario que más comparte en la red social*/
            void amplificador(map<int, vector<string> > compartidos) {                
                int mayor=0;
                auto amplificador;
                for(auto i=compartidos.begin(); i!=compartidos.end(); i++) {
                    if(i->first > mayor) {
                        amplificador = i->second;
                        mayor = i->first;
                    }                    
                }
                cout << "El usuario que más comparte en la red social es: " << amplificador << endl;
            }

            /*Crea un árbol donde el id sea la cantidad de comentarios que hace un usuario. 
            Crea un método llamado callado, que indique el usuario que menos comenta*/
            void callado(map<int, vector<string> > comentarios) {                
                int menor=100;
                auto callado;
                for(auto i=comentarios.begin(); i!=comentarios.end(); i++) {
                    if(i->first < menor) {
                        callado = i->second;
                        menor = i->first;
                    }                    
                }
                cout << "El usuario que menos comenta es: " << callado << endl;
            }
};

int main() {
    //Cambia la ruta a donde se encuentra el archivo
    //Ejemplo windows en WSL: /mnt/c/Users/Jorge/Desktop/file.txt
    //Ejemplo Mac: /Users/Jorge/Desktop/file.txt
    //En la misma carpeta: file.txt
    string path="/Users/marcefuentes/Documents/Tec/4to Semestre/Estructura de Datos/examenA01748161Marcela.txt";
    leerData(path);
    for(auto i: interacciones){
        cout<<i.user1<<":"<<i.inter<<":"<<i.user2<<endl;
    }
    return 0;
}