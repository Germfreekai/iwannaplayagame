// Marcela Fuentes, A01748161
// Actividad de repaso 3

#include <iostream>
using namespace std;

int busquedaSecuencial(int *a, int buscado, int size){
	for(int i=0; i<size; i++){
		if(a[i]==buscado){
			return i;
		}
	}
	return -1;
}

class Paciente {
    public:
		int id;
		string nombre;
		int edad;
		string enfermedad;
};

class Hospital {
    public:
		int numeroCamas;

		Hospital(int nC) {
	        numeroCamas=nC;
	        camas=new int[numeroCamas]();
	        pacientes=new Paciente[numeroCamas]();
	        for(int i=0; i<numeroCamas; i++){
		    camas[i]=0;
	        }
        }

		void ingresarPaciente(int id, string nombre, int edad) {
	        int index=busquedaSecuencial(camas, 0, numeroCamas);
	        if(index==-1){
		        cout<<"No hay camas disponibles para "<<nombre<<endl;
		        return;
	        }
	        camas[index]=id;
	        pacientes[index].id=id;
	        pacientes[index].nombre=nombre;
	        pacientes[index].edad=edad;
	        pacientes[index].enfermedad="";
	        cout<<nombre<<" admitido en la cama "<<index<<endl;
        }

        void imprimirPacientes() {
            for(int i=0; i<numeroCamas; i++){
		        if(camas[i]!=0){
			    cout<<"Cama: "<<i<<", Paciente: "<<pacientes[i].nombre;
			    cout<<", edad: "<<pacientes[i].edad<<", id: "<<pacientes[i].id;
			    cout<<", enfermedad: "<<pacientes[i].enfermedad<<endl;
		        }
	        }
        }

		void altaPaciente(int id) {
	        int index=busquedaSecuencial(camas, id, numeroCamas);
	            if(index==-1){
		            cout<<"El paciente no está en el hospital"<<endl;
		            return;
	            }
	        cout<<"Dando de alta a "<<pacientes[index].nombre<<" de la cama "<<index<<endl;
	        camas[index]=0;
	        pacientes[index].id=0;
	        pacientes[index].nombre="";
	        pacientes[index].edad=0;
	        pacientes[index].enfermedad="";
        }

		void asignarEnfermedad(int id, string enfermedad) {
	        int index=busquedaSecuencial(camas, id, numeroCamas);
	            if(index==-1){
		            cout<<"El paciente no está en el hospital"<<endl;
		            return;
	            }
	        pacientes[index].enfermedad=enfermedad;
        }

		~Hospital() {
	        delete [] camas;
	        delete [] pacientes;
        }
		
	private:
		int *camas;
		Paciente *pacientes;
};

int main() {
    Hospital h(3);
	h.ingresarPaciente(20, "Juanito", 20);
	h.ingresarPaciente(21, "Ana", 30);
	h.ingresarPaciente(30, "Danielito", 31);
	h.imprimirPacientes();
	h.ingresarPaciente(40, "María", 39);
	h.altaPaciente(20);
	h.ingresarPaciente(40, "María", 39);
	h.asignarEnfermedad(30, "Coronavirus");
	h.imprimirPacientes();
	return 0;
}