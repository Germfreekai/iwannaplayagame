// Marcela Fuentes, A01748161
// Actividad 1.1, Año bisiesto
#include <iostream>

using namespace std;

int main() {
    cout << "Este programa te ayuda a saber si un año es bisiesto." << endl;
    int a = 0;
    cout << "Dame un año: "<<endl;
    cin >> a;

    if (a%4==0) {
        if (a%100==0) {
            if (a%400==0) {
                cout << "Sí es bisiesto!"<<endl;
            } else {
                cout << "No es bisiesto."<<endl;
            }
        } else {
            cout << "Sí es bisiesto!"<<endl;
        }
    } else {
        cout << "No es bisiesto."<<endl;
    }
}