// Marcela Fuentes, A01748161
// Actividad de repaso 1

#include <iostream>
using namespace std;

class Avion {
    public:
        int numAsientos;
        int* asientos;
        
        Avion(int nA) {
            numAsientos = nA;
            asientos = new int[numAsientos]();
            for(int i=0; i<numAsientos; i++) {
                asientos[i]=0;
            }
        }

        void checkIn(int numPasajero, int asiento) {
            asientos[asiento] = numPasajero;
        }

        int verificar(int numPasajero) {
            for(int i=0; i<numAsientos; i++) {
                if(asientos[i]==numPasajero) {
                    return 1;
                }
            }
            return -1;
        }

        ~Avion() {
            delete [] asientos;
        }

        
};

int main() {
    Avion amx365(30);
    amx365.checkIn(12345, 2);
    amx365.checkIn(5674, 7);
    amx365.checkIn(123, 21);
    cout<<amx365.verificar(12345)<<endl;
    cout<<amx365.verificar(10)<<endl;
}