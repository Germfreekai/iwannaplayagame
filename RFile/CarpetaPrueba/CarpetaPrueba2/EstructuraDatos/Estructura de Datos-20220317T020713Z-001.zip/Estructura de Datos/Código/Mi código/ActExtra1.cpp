// Marcela Fuentes, A01748161
// Actividad extra examen 1.1 Fibonacci

#include <iostream>
using namespace std;

int fibonacci(int x) {
   if(x==1) {
      return x;
   } if(x==0) {
       return x;
   } else {
        return (fibonacci(x-1)+fibonacci(x-2));
   }
}
int main() {
   int x;
   cout << "¿Qué elemento de la secuencia de Fibonacci quieres saber? ";
   cin >> x;
   cout << "El elemento en la secuencia de Fibonacci correspondiente a esa posición es: " << fibonacci(x) << endl;
   return 0;
}