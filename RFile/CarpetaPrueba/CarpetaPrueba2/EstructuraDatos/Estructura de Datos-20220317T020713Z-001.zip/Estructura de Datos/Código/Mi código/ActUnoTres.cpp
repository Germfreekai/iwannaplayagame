// Marcela Fuentes, A01748161
// Actividad 1.3, Contador de palabras
#include <iostream>
#include <string>
using namespace std;

int main() {
    cout << "Este programa te ayuda a saber cuántas veces se repite una palabra en una frase." << endl;
    string frase = "";
    string palabra = "";
    int contador = 0;

    cout << "Dame una frase: " << endl;
    getline(cin, frase);
    cout << "Dame una palabra: " << endl;
    getline(cin, palabra);

    size_t posicion = frase.find(palabra);
    while (posicion!=-1) {
        contador++;
        posicion = frase.find(palabra, posicion+1);
    }
    cout << "Encontré la palabra " << contador << " veces." <<endl;
}