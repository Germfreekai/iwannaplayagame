#include <iostream>
#include <vector>
using namespace std;

template <class K, class V>
class KeyPair{
	public:
	K key;
	V value;
	
	KeyPair(){
		key=NULL;
		value=NULL;
	}
	
	KeyPair(K key, V val){
		this->key=key;
		this->value=val;
	}
};

template <class K, class V>
class Dictionary{
	public:
	vector<KeyPair<K,V> > *dict;
	int positions;
	
	Dictionary(){
		positions=10;
		dict=new vector<KeyPair<K,V> >[positions];
	}
	
	Dictionary(int pos) {
		positions=pos;
		dict=new vector<KeyPair<K,V> >[positions];
	}
	
	void insert(K key, V value) {
		KeyPair<K,V> kp(key, value);
		int hash=key%positions;
		for(int i=0; i<dict[hash].size(); i++){
			if(dict[hash][i].key==key){
				cout<<"llave ya existente"<<endl;
				return;
			}
		}
		dict[hash].push_back(kp);
	}
	
	V checkAtKey(K key) {
		int hash=key%positions;
		for(int i=0; i<dict[hash].size(); i++) {
			if(dict[hash][i].key==key) {
				return dict[hash][i].value;
			} else {
				cout<<"No encontré ese valor"<<endl;
			}
		}
	}
	
	void printDictionary() {
		for(int i=0; i<positions; i++) {
			cout<<"["<<i<<"]: ";
			for(int j=0; j<dict[i].size(); j++) {
				cout<<"("<<dict[i][j].key<<", "<<dict[i][j].value<<"), ";
			}
			cout<<""<<endl;
		}
	}
};

int main() {
	Dictionary<int, string> a;
	a.insert(15, "Hola");
	a.insert(23, "Perro");
	a.insert(9, "Gato");
	a.insert(1501, "Adios");
	a.insert(301, "Nuevo");
	a.printDictionary();
	return 0;
}