// Marcela Fuentes, A01748161
// Tarea 6, Set

#include <iostream>
#include <vector>
using namespace std;

template <class K>
class set {
    public:
        vector<K> *setkey;
        int positions;
        int key;

        set() {
            positions=10;
            setkey=new vector<K>[positions];
	    }
	
        set(int pos) {
            positions=pos;
            setkey=new vector<K>[positions];
        }
        
        void insert(int key) {
            vector<K> k(key);
		    int hash=key%positions;
		    for(int i=0; i<setkey[hash].size(); i++){
			    if(setkey[hash][i]==key){
				    cout<<"llave ya existente"<<endl;
				    return;
			    }
		    }
		    setkey[hash].push_back(key);
        }
        
        int checkAtKey(int key) {
            int hash=key%positions;
            for(int i=0; i<setkey[hash].size(); i++) {
                if(key!=setkey[hash][i]) {
                    cout<<"No encontré ese valor"<<endl;
                } else {
                    return setkey[hash][i];
                }
            }
        }
        
        void printSet() {
            for(int i=0; i<positions; i++) {
                for(auto j=setkey[i].begin(); j!=setkey[i].end(); j++) {
                    cout<<"Key: "<<(*j)<<endl;
                }
            }
        }
};

int main() {
    set<int> s;
    s.insert(5);
    s.insert(3);
    s.insert(1);
    s.printSet();
    return 0;
}