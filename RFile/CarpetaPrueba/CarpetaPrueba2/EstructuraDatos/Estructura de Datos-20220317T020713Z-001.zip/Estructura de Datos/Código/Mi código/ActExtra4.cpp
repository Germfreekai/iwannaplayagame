// Marcela Fuentes, A01748161
// Actividad extra examen 1.4 Búsqueda Ordenada II

#include <iostream>
using namespace std;

int busAuxRec(int *a, int inicio, int fin, int buscado) {
        if(a[inicio]==buscado) {
            return inicio;
        } else {
            return busAuxRec(a, inicio-1, fin, buscado);
        }
        return -1;
}

int busOrdIIRec(int *a, int size, int buscado, int paso) {
    int finBloque = size+paso-1;
    if (size-1<finBloque) {
        finBloque=size-1;
    } if (a[finBloque]>=buscado) {
        return busAuxRec(a, finBloque, size, buscado);
    }
    return -1;
}

int main() {
    int size=7;
    int *a=new int[size]();
    a[0]=1;
    a[1]=3;
    a[2]=5;
    a[3]=7;
    a[4]=9;
    a[5]=11;
    a[6]=13;

    cout << busOrdIIRec(a, size, 7, 2) << endl;
    return 0;
}