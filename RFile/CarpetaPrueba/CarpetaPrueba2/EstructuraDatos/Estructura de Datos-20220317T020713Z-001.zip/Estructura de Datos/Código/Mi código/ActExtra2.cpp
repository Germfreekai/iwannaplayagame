// Marcela Fuentes, A01748161
// Actividad extra examen 1.2 Búsqueda Secuencial

#include <iostream>
using namespace std;

int busSecRec(int* a, int buscado, int size) {
    if (size < 0) {
        return -1;
    } if (a[size]==buscado) {
        return size;
    } else {
        return busSecRec(a, buscado, size-1);
    }
}

int main() {
    int size=7;
    int *a=new int[size]();
    a[0]=1;
    a[1]=3;
    a[2]=5;
    a[3]=7;
    a[4]=9;
    a[5]=11;
    a[6]=13;

    cout << busSecRec(a, 7, size) << endl;
    return 0;
}