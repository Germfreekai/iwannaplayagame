// Marcela Fuentes, A01748161
// Actividad 3, Problema 1

#include <iostream>
using namespace std;

class Figura {
    public:
        double perimetro;
        double area;
        
        virtual double calcPer()=0;
        virtual double calcAr()=0;

        double x;
        double y;
};

// Se asume que el triángulo es equilátero
class Triangulo:public Figura {
    public:
        Triangulo(double lado, double altura) {
            x = lado;
            y = altura;
        }
        
        double calcPer() {
            perimetro = (x*3);
            return perimetro;
        }

        double calcAr() {
            area = ((x*y)/2);
            return area;
        }
};

class Cuadrado:public Figura {
    public:
        Cuadrado(double lado) {
            x = lado;
    }
        
        double calcPer() {
            perimetro = (x*4);
            return perimetro;
        }

        double calcAr() {
            area = (x*x);
            return area;
        }
};

int main() {
    cout<<"Perímetro y área de un cuadrado de lado 3"<<endl;
    Cuadrado c(3);
    cout<<"El perímetro es: "<<c.calcPer()<<endl;
    cout<<"El área es: "<<c.calcAr()<<endl;

    cout<<""<<endl;

    cout<<"Perímetro y área de un triángulo de lado 3 y altura 5"<<endl;
    Triangulo t(3, 5);
    cout<<"El perímetro es: "<<t.calcPer()<<endl;
    cout<<"El área es: "<<t.calcAr()<<endl;
}