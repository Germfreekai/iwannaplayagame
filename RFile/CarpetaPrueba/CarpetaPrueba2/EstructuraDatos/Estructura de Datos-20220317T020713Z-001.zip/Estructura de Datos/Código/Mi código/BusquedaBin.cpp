// Marcela Fuentes, A01748161
// Búsqueda Binaria

#include <iostream>
using namespace std;

int busquedaBinaria(int[] E, int primero, int ultimo, int k) {
    if (ultimo < primero) {
        int indice = -1;
    } else {
        int medio = (primero + ultimo)/2;       // División entera
        if (k==E[medio]) {
            indice = medio;
        } else if (k<E[medio]) {
            indice = busquedaBinaria(E, primero, medio-1, k);
        } else {
            indice = busquedaBinaria(E, medio+1, ultimo, k);
        }
    }
    return indice;
}

int main() {
    int size=7;
    int *a=new int[size]();
    a[0]=1;
    a[1]=3;
    a[2]=5;
    a[3]=7;
    a[4]=9;
    a[5]=11;
    a[6]=13;
    cout<<a[0]<<endl;
    cout<<busquedaBinaria(a, 1, 13, 11)<<endl;
    return 0;
}