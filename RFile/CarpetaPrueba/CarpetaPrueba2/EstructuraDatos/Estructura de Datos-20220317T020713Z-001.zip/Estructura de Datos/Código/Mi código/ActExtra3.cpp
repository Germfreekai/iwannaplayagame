// Marcela Fuentes, A01748161
// Actividad extra examen 1.3 Búsqueda Ordenada I

#include <iostream>
using namespace std;

int busOrdIRec(int *a, int buscado, int size) {
    if (buscado > a[size-1]) {
        return -1;
    } if (a[size-1]==buscado) {
        return size-1;
    } else {
        return busOrdIRec(a, buscado, size-1);
    }
    return -1;
}

int main() {
    int size=7;
    int *a=new int[size]();
    a[0]=1;
    a[1]=3;
    a[2]=5;
    a[3]=7;
    a[4]=9;
    a[5]=11;
    a[6]=13;

    cout << busOrdIRec(a, 4, size) << endl;
    return 0;
}