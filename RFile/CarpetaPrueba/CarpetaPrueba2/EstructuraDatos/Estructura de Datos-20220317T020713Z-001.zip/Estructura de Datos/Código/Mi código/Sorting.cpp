// Marcela Fuentes, A01748161
// Métodos de Sorting (acomodar)

#include <iostream>
using namespace std;

template <class T>
class Sort {
    public:
        virtual void sort(T *a, int size) = 0;

        void intercambiar(T *a, int pos1, int pos2) {
            T x = a[pos1];
            a[pos1] = a[pos2];
            a[pos2] = x;
        }
        
        void imprimirArreglo(T *a, int size) {
            cout << a[0];
            for(int i=1; i<size; i++) {
                cout << ", "<<a[i];
            }
            cout<<endl;
        }
};

template <class T>
class LuckySort: public Sort<T> {
    public:
        void sort(T *a, int size) {
            this->intercambiar(a, 0, size-1);
        }
};

template <class T>
class SelectionSort: public Sort<T> {
    public:
        void sort(T *a, int size) {
            for (int i=0; i<size-1; i++)  {
                int p = i;
                for (int j = i+1; j<size; j++) {
                    if (a[j]<a[p]) {
                    p = j;
                    }
                }
                this->intercambiar(a, i, p);
            }
        }   
};

template <class T>
class BubbleSort: public Sort<T> {
    public:
        void sort(T *a, int size) {
            for(int i=0; i<size-1; i++) {
                for(int j=0; j<size-1-i; j++) {
                    if(a[j]>a[j+1]) {
                        this->intercambiar(a, j+1, j);
                    }
                }
            }
        }
};

template <class T>
class InsertionSort: public Sort<T> {
    public:
        void sort(T *a, int size) {
            for(int i=1; i<size; i++) {
                for(int j=i; j>0; i--) {
                    if(a[j]>a[j-1]) {
                        this->intercambiar(a, j, j-1);
                    } else {
                        break;
                    }
                }
            }
        }
};

template <class T>
class MergeSort: public Sort<T>{
	
	
	public:
	void sort(T *a, int size){
		sortAux(a, 0, size-1);
	}
	
	private:
	void sortAux(T *a, int inicio, int fin){
		if(inicio>=fin){
			return;
		}
		int medio=(fin+inicio)/2;
		sortAux(a, inicio, medio);
		sortAux(a, medio+1, fin);
		merge(a, inicio, medio, fin);
	}
	
	
	
	void merge(T *a, int inicio, int medio, int fin){
		//Tam de la copia
		int tamIzq=medio-inicio+1;
		int tamDer=fin-medio;

		//Crear espacio para copia
		T *copiaIzq=new T[tamIzq]();
		T *copiaDer=new T[tamDer]();
		//Copiando los elementos
		for(int i=0; i<tamIzq; i++){
			copiaIzq[i]=a[inicio+i];
		}
		for(int i=0; i<tamDer; i++){
			copiaDer[i]=a[medio+1+i];
		}
		//Indices
		int I=0;
		int D=0;
		int x=inicio;
		//Comparaciones
		while(I<tamIzq&&D<tamDer){
			if(copiaIzq[I]<copiaDer[D]){
				a[x]=copiaIzq[I];
				I++;
			}else{
				a[x]=copiaDer[D];
				D++;
			}
			x++;
		}
		if(I==tamIzq){
			while(D<tamDer){
				a[x]=copiaDer[D];
				D++;
				x++;
			}
		}else{
			while(I<tamIzq){
				a[x]=copiaIzq[I];
				I++;
				x++;
			}
		}	
	}
};


int main() {
    int size=7;
    int *a=new int[size]();
    a[0]=9;
    a[1]=5;
    a[2]=3;
    a[3]=11;
    a[4]=20;
    a[5]=1;
    a[6]=13;
    MergeSort<int> s;
    s.imprimirArreglo(a, size);
    s.sort(a, size);
    s.imprimirArreglo(a, size);
    return 0;
}