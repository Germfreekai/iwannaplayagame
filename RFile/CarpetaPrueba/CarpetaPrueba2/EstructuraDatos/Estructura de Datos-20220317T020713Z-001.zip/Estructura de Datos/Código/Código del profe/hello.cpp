#include <iostream>

using namespace std;

int main(){
    cout<<"Hello World!"<<endl;
    int a=1;
    double b=1.1;
    char c='a';//esto es un caracter
    string d="hola";
    cout<<"Dame un numero: ";
    cin>>a;
    cout<<"El numero dado fue: "<<a<<endl;
    return 0;
}